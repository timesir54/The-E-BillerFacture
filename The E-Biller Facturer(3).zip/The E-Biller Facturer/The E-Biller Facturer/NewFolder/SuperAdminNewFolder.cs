﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_E_Biller_Facturer.NewFolder
{
    public class SuperAdminNewFolder
    {
        public static string Username = "sir";
        public static string Password = "54500";
    }
}
