﻿namespace The_E_Biller_Facturer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Titulo = new Label();
            btnIN = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Titulo
            // 
            Titulo.AutoSize = true;
            Titulo.BackColor = SystemColors.Control;
            Titulo.Font = new Font("Times New Roman", 26.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            Titulo.ForeColor = Color.LimeGreen;
            Titulo.Location = new Point(255, 9);
            Titulo.Name = "Titulo";
            Titulo.Size = new Size(465, 40);
            Titulo.TabIndex = 0;
            Titulo.Text = "THE E-BILLER FACTURER";
            Titulo.Click += Titulo_Click;
            // 
            // btnIN
            // 
            btnIN.BackColor = Color.LimeGreen;
            btnIN.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnIN.ForeColor = Color.White;
            btnIN.Location = new Point(343, 348);
            btnIN.Name = "btnIN";
            btnIN.Size = new Size(245, 139);
            btnIN.TabIndex = 2;
            btnIN.Text = "ACCEDER";
            btnIN.UseVisualStyleBackColor = false;
            btnIN.Click += btnIN_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = null;
            pictureBox1.Image = Properties.Resources.logo_the_E_BILLER;
            pictureBox1.Location = new Point(315, 74);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(327, 268);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(900, 499);
            Controls.Add(pictureBox1);
            Controls.Add(btnIN);
            Controls.Add(Titulo);
            Name = "Form1";
            Text = "The E-Biller Facturer";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Titulo;
        private Button btnIN;
        private PictureBox pictureBox1;
    }
}