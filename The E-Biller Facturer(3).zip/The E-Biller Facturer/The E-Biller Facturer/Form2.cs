﻿


using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;






namespace The_E_Biller_Facturer
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }



      
        

       

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            List<Datos> tusDatos = ObtenerDatosFicticios();

            Document doc = new Document();
            string outputPath = @"C:\Users\USER\Downloads";
            string fileName = Path.Combine(outputPath, "factura.pdf");


            try
            {
                PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(fileName, FileMode.Create));
                doc.Open();

                iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance("C:/Users/USER/Desktop/The E-Biller Facturer/The E-Biller Facturer/Resources/logo the E-BILLER.jpg");
                logo.ScaleAbsolute(100, 50);
                doc.Add(logo);

                Paragraph titulo = new Paragraph("THE E BILLER FACTURER");
                titulo.Alignment = Element.ALIGN_CENTER;
                doc.Add(titulo);

                Paragraph subtitulo = new Paragraph("FACTURA DE PAGO");
                subtitulo.Alignment = Element.ALIGN_CENTER;
                doc.Add(subtitulo);

                Paragraph fecha = new Paragraph("Fecha de Generación: " + DateTime.Now.ToShortDateString());
                fecha.Alignment = Element.ALIGN_RIGHT;
                doc.Add(fecha);



                PdfPTable tabla = new PdfPTable(4);

                // Encabezados de las columnas
                PdfPCell cellNombreHeader = new PdfPCell(new Phrase("Nombre"));
                PdfPCell cellFechaHeader = new PdfPCell(new Phrase("Fecha"));
                PdfPCell cellDebeHeader = new PdfPCell(new Phrase("Lo que Debe"));
                PdfPCell cellTotalHeader = new PdfPCell(new Phrase("Total"));

                // Alineación de los encabezados
                cellNombreHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                cellFechaHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                cellDebeHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                cellTotalHeader.HorizontalAlignment = Element.ALIGN_CENTER;

                // Agregar encabezados a la tabla
                tabla.AddCell(cellNombreHeader);
                tabla.AddCell(cellFechaHeader);
                tabla.AddCell(cellDebeHeader);
                tabla.AddCell(cellTotalHeader);



                foreach (var item in tusDatos)
                {
                    PdfPCell cellNombre = new PdfPCell(new Phrase(item.Nombre));
                    PdfPCell cellFecha = new PdfPCell(new Phrase(item.Fecha.ToString()));
                    PdfPCell cellDebe = new PdfPCell(new Phrase(item.Debe.ToString()));

                    decimal total = item.Pago - item.Debe;
                    PdfPCell cellTotal = new PdfPCell(new Phrase(total.ToString()));

                    tabla.AddCell(cellNombre);
                    tabla.AddCell(cellFecha);
                    tabla.AddCell(cellDebe);
                    tabla.AddCell(cellTotal);
                }


                doc.Add(tabla);
                doc.Close();
                writer.Close();

                MessageBox.Show("PDF generado exitosamente: " + fileName, "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el PDF: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private List<Datos> ObtenerDatosFicticios()
        {





            List<Datos> datos = new List<Datos>
            {
                new Datos
                {
                    Nombre = textBoxN.Text,
                    Fecha = DateTime.Now,
                    Pago = Convert.ToDecimal(textBoxP.Text),
                    Debe = Convert.ToDecimal(textBoxD.Text)
                },


            };

            return datos;

        }



        public class Datos
        {
            public string? Nombre { get; set; }
            public DateTime Fecha { get; set; }
            public decimal Pago { get; set; }
            public decimal Debe { get; set; }
        }









        private void lblFecha_Click(object sender, EventArgs e)
        {

        }

        private void btnInformation_Click(object sender, EventArgs e)
        {
            int n = dtgvFacture.Rows.Add();

            //informacion
            dtgvFacture.Rows[n].Cells[0].Value = textBoxN.Text;
            dtgvFacture.Rows[n].Cells[1].Value = textBoxF.Text;
            dtgvFacture.Rows[n].Cells[2].Value = textBoxP.Text;
            dtgvFacture.Rows[n].Cells[3].Value = textBoxD.Text;
            dtgvFacture.Rows[n].Cells[4].Value = textBoxO.Text;
            //TEXTBOX CLEAN
            textBoxN.Text = "";
            textBoxF.Text = "";
            textBoxP.Text = "";
            textBoxD.Text = "";
            textBoxO.Text = "";



        }
        private void dtgvFacture_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblDebe_Click(object sender, EventArgs e)
        {

        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void textBoxP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.')) {
                e.Handled = true;

            
            
            
            
            }
            //solo 1 punto decimal

#pragma warning disable CS8602 // Desreferencia de una referencia posiblemente NULL.
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1)) {

                e.Handled = true;




            }

#pragma warning disable CS8602 // Desreferencia de una referencia posiblemente NULL.

        }

        private void textBoxD_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;





            }
            //solo 1 punto decimal


#pragma warning disable CS8602 // Desreferencia de una referencia posiblemente NULL.
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {

                e.Handled = true;




            }
#pragma warning restore CS8602 // Desreferencia de una referencia posiblemente NULL.

        }
    }




}



