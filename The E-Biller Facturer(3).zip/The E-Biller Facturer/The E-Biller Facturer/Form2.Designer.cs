﻿namespace The_E_Biller_Facturer
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnImprimir = new Button();
            lblNombre = new Label();
            lblFecha = new Label();
            lblPago = new Label();
            lblDebe = new Label();
            lblTotal = new Label();
            textBoxN = new TextBox();
            textBoxF = new TextBox();
            textBoxP = new TextBox();
            textBoxD = new TextBox();
            textBoxO = new TextBox();
            btnInformation = new Button();
            dtgvFacture = new DataGridView();
            nombre = new DataGridViewTextBoxColumn();
            fecha = new DataGridViewTextBoxColumn();
            pago = new DataGridViewTextBoxColumn();
            debe = new DataGridViewTextBoxColumn();
            total = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dtgvFacture).BeginInit();
            SuspendLayout();
            // 
            // btnImprimir
            // 
            btnImprimir.BackColor = Color.LimeGreen;
            btnImprimir.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnImprimir.ForeColor = Color.White;
            btnImprimir.Location = new Point(513, 394);
            btnImprimir.Name = "btnImprimir";
            btnImprimir.Size = new Size(75, 60);
            btnImprimir.TabIndex = 1;
            btnImprimir.Text = "Imprimir";
            btnImprimir.UseVisualStyleBackColor = false;
            btnImprimir.Click += btnImprimir_Click;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Times New Roman", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblNombre.Location = new Point(25, 39);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(52, 15);
            lblNombre.TabIndex = 2;
            lblNombre.Text = "Nombre:";
            
            // 
            // lblFecha
            // 
            lblFecha.AutoSize = true;
            lblFecha.Font = new Font("Times New Roman", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblFecha.Location = new Point(274, 39);
            lblFecha.Name = "lblFecha";
            lblFecha.Size = new Size(42, 15);
            lblFecha.TabIndex = 3;
            lblFecha.Text = "Fecha:";
            lblFecha.Click += lblFecha_Click;
            // 
            // lblPago
            // 
            lblPago.AutoSize = true;
            lblPago.Font = new Font("Times New Roman", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblPago.Location = new Point(25, 129);
            lblPago.Name = "lblPago";
            lblPago.Size = new Size(37, 15);
            lblPago.TabIndex = 4;
            lblPago.Text = "Pago:";
            // 
            // lblDebe
            // 
            lblDebe.AutoSize = true;
            lblDebe.Font = new Font("Times New Roman", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblDebe.Location = new Point(278, 129);
            lblDebe.Name = "lblDebe";
            lblDebe.Size = new Size(38, 15);
            lblDebe.TabIndex = 5;
            lblDebe.Text = "Debe:";
            lblDebe.Click += lblDebe_Click;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Times New Roman", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal.Location = new Point(193, 211);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(37, 15);
            lblTotal.TabIndex = 6;
            lblTotal.Text = "Total:";
            lblTotal.Click += lblTotal_Click;
            // 
            // textBoxN
            // 
            textBoxN.Location = new Point(82, 31);
            textBoxN.Name = "textBoxN";
            textBoxN.Size = new Size(100, 23);
            textBoxN.TabIndex = 7;
            
            // 
            // textBoxF
            // 
            textBoxF.Location = new Point(321, 31);
            textBoxF.Name = "textBoxF";
            textBoxF.Size = new Size(100, 23);
            textBoxF.TabIndex = 8;
            
            // 
            // textBoxP
            // 
            textBoxP.Location = new Point(65, 129);
            textBoxP.Name = "textBoxP";
            textBoxP.Size = new Size(100, 23);
            textBoxP.TabIndex = 9;
            
            textBoxP.KeyPress += textBoxP_KeyPress;
            // 
            // textBoxD
            // 
            textBoxD.Location = new Point(321, 126);
            textBoxD.Name = "textBoxD";
            textBoxD.Size = new Size(100, 23);
            textBoxD.TabIndex = 10;
            
            textBoxD.KeyPress += textBoxD_KeyPress;
            // 
            // textBoxO
            // 
            textBoxO.Location = new Point(234, 211);
            textBoxO.Name = "textBoxO";
            textBoxO.Size = new Size(100, 23);
            textBoxO.TabIndex = 11;
         
            // 
            // btnInformation
            // 
            btnInformation.BackColor = Color.LimeGreen;
            btnInformation.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnInformation.ForeColor = Color.White;
            btnInformation.Location = new Point(416, 276);
            btnInformation.Name = "btnInformation";
            btnInformation.Size = new Size(144, 34);
            btnInformation.TabIndex = 12;
            btnInformation.Text = "Agregar informacion";
            btnInformation.UseVisualStyleBackColor = false;
            btnInformation.Click += btnInformation_Click;
            // 
            // dtgvFacture
            // 
            dtgvFacture.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvFacture.Columns.AddRange(new DataGridViewColumn[] { nombre, fecha, pago, debe, total });
            dtgvFacture.Location = new Point(3, 347);
            dtgvFacture.Name = "dtgvFacture";
            dtgvFacture.RowTemplate.Height = 25;
            dtgvFacture.Size = new Size(500, 126);
            dtgvFacture.TabIndex = 13;
            // 
            // nombre
            // 
            nombre.HeaderText = "Nombre";
            nombre.Name = "nombre";
            // 
            // fecha
            // 
            fecha.HeaderText = "Fecha";
            fecha.Name = "fecha";
            // 
            // pago
            // 
            pago.HeaderText = "Pago";
            pago.Name = "pago";
            // 
            // debe
            // 
            debe.HeaderText = "Debe";
            debe.Name = "debe";
            // 
            // total
            // 
            total.HeaderText = "Total";
            total.Name = "total";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(600, 497);
            Controls.Add(dtgvFacture);
            Controls.Add(btnInformation);
            Controls.Add(textBoxO);
            Controls.Add(textBoxD);
            Controls.Add(textBoxP);
            Controls.Add(textBoxF);
            Controls.Add(textBoxN);
            Controls.Add(lblTotal);
            Controls.Add(lblDebe);
            Controls.Add(lblPago);
            Controls.Add(lblFecha);
            Controls.Add(lblNombre);
            Controls.Add(btnImprimir);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)dtgvFacture).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnImprimir;
        private Label lblNombre;
        private Label lblFecha;
        private Label lblPago;
        private Label lblDebe;
        private Label lblTotal;
        private TextBox textBoxN;
        private TextBox textBoxF;
        private TextBox textBoxP;
        private TextBox textBoxD;
        private TextBox textBoxO;
        private Button btnInformation;
        private DataGridView dtgvFacture;
        private DataGridViewTextBoxColumn nombre;
        private DataGridViewTextBoxColumn fecha;
        private DataGridViewTextBoxColumn pago;
        private DataGridViewTextBoxColumn debe;
        private DataGridViewTextBoxColumn total;
    }
}