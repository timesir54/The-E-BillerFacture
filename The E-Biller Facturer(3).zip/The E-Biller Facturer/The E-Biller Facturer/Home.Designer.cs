﻿namespace The_E_Biller_Facturer
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTITULO = new Label();
            btnPrint = new Button();
            btnAD = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTITULO
            // 
            lblTITULO.AutoSize = true;
            lblTITULO.Font = new Font("Times New Roman", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblTITULO.ForeColor = Color.LimeGreen;
            lblTITULO.Location = new Point(163, 36);
            lblTITULO.Name = "lblTITULO";
            lblTITULO.Size = new Size(465, 40);
            lblTITULO.TabIndex = 0;
            lblTITULO.Text = "THE E-BILLER FACTURER";
            lblTITULO.Click += lblTITULO_Click;
            // 
            // btnPrint
            // 
            btnPrint.BackColor = Color.LimeGreen;
            btnPrint.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnPrint.ForeColor = Color.White;
            btnPrint.Location = new Point(28, 23);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(96, 53);
            btnPrint.TabIndex = 2;
            btnPrint.Text = "Imprimir";
            btnPrint.UseVisualStyleBackColor = false;
            btnPrint.Click += btnPrint_Click;
            // 
            // btnAD
            // 
            btnAD.BackColor = Color.LimeGreen;
            btnAD.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnAD.ForeColor = Color.White;
            btnAD.Location = new Point(634, 35);
            btnAD.Name = "btnAD";
            btnAD.Size = new Size(166, 41);
            btnAD.TabIndex = 3;
            btnAD.Text = "Administracion de pagos";
            btnAD.UseVisualStyleBackColor = false;
            btnAD.Click += btnAD_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_the_E_BILLER;
            pictureBox1.Location = new Point(218, 146);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(334, 210);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(btnAD);
            Controls.Add(btnPrint);
            Controls.Add(lblTITULO);
            Name = "Home";
            Text = "Home";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTITULO;
        private Button btnPrint;
        private Button btnAD;
        private PictureBox pictureBox1;
    }
}